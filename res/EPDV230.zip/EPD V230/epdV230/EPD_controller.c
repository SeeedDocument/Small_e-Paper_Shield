/**
* \file
*
* \brief The interface for writing to epd from application
*
* Copyright (c) 2012-2014 Pervasive Displays Inc. All rights reserved.
*
*  Author : Muchiri John
*  For: SeeedStudio EPD shield (c) 2014 seeedstudio
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*  1. Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*  2. Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#include  "EPD_controller.h"

/**
 * \brief Initialize the EPD hardware setting 
 */
void EPD_display_init(void) {
	EPD_init();
}

/**
 * \brief begin epd with initalizing
 *
 * \param EPD_type_index The defined EPD size
 * \param inv_image enable/disable image
 */
void EPD_begin(uint8_t EPD_type_index, uint8_t inv_image)
{
	epd_data.user_epd_type = EPD_type_index;
	epd_data.inverse_image = inv_image;
}

/**
 * \brief Show image from the pointer of flash memory array
 *
 * \param EPD_type_index The defined EPD size
 * \param new_image_ptr The pointer of memory that stores new image
 */
void EPD_image_flash(PROGMEM const unsigned int *new_image) 
{
	//flash image
	epd_data.image_data = new_image;
	/* Initialize EPD hardware */
	EPD_init();
	/* Power on COG Driver */
	EPD_power_on();
	/* Initialize COG Driver */
	EPD_initialize_driver(epd_data.user_epd_type);
	/* Display image data on EPD from image array */
	EPD_display_from_flash_prt(epd_data.user_epd_type, 1);
	/* Power off COG Driver */
	EPD_power_off (epd_data.user_epd_type);
}

/**
 * \brief Show image from the pointer of sram memory array
 *
 * \param EPD_type_index The defined EPD size
 * \param new_image_ptr The pointer of memory that stores new image
 */
void EPD_image_sram(uint8_t *new_image) 
{
	//epd sram data
	epd_data.image_data = new_image;
	//init
	EPD_init();
	/* Power on COG Driver */
	EPD_power_on();
	/* Initialize COG Driver */
	EPD_initialize_driver(epd_data.user_epd_type);
	/* Display image data on EPD from image array */
	EPD_display_from_sram_prt(epd_data.user_epd_type, 2);
	/*power off*/
	EPD_power_off (epd_data.user_epd_type);
}

/**
 * \brief Show image from the pointer of sd
 *
 * \param EPD_type_index The defined EPD size
 * \param new_image_ptr The pointer of memory that stores new image
 */
void EPD_image_sd(EPD_read_from_sd_handler _EPD_read) 
{
	EPD_init();
	/* Power on COG Driver */
	EPD_power_on();
	/* Initialize COG Driver */
	EPD_initialize_driver(epd_data.user_epd_type);
	//read line handler
	_EPD_read_sd_handler = _EPD_read;
	/* Display image data on EPD from sd */
	EPD_display_from_sd(epd_data.user_epd_type);
	//power off
	EPD_power_off (epd_data.user_epd_type);
}
/**
 * \brief clear display -white
 *
 * \param EPD_type_index The defined EPD size
 */
void EPD_clear() 
{
	/* Initialize EPD hardware */
	EPD_init();
	/* Power on COG Driver */
	EPD_power_on();
	/* Initialize COG Driver */
	EPD_initialize_driver(epd_data.user_epd_type);
	/* Display image data on EPD from image array */
	EPD_display_from_flash_prt(epd_data.user_epd_type, 3);
	//power off
	EPD_power_off (epd_data.user_epd_type);
}

//line handlers

/**
 * \brief Read Flash data into buffer
 *
 * \param flash_address The start address of Flash
 * \param target_buffer The target address of buffer will be read
 * \param byte_length The data length will be read
 */
void flash_cmd_read(long address, uint8_t *byte_array, long byte_length ) 
{
	int x=0;
	uint8_t data;
	for (x=0 ; x < byte_length ; x++)
	{
		/*read byte*/
		data = (uint8_t)pgm_read_byte((&epd_data.image_data[address+x])) & 0xFF;
		/*inverse image if enabled*/
		if(epd_data.inverse_image) data=~data;
		/*write image data to buffer*/
		*(byte_array+x) = data;
	}
}

/**
 * \brief Read Flash data into buffer
 *
 * \param flash_address The start address of Flash
 * \param target_buffer The target address of buffer will be read
 * \param byte_length The data length will be read
 */
void sram_cmd_read(long sram_address, uint8_t *byte_array, uint8_t byte_length) {

	int x=0;
	uint8_t data;
	/*fill line*/
	for (x =0 ; x < byte_length ; x++) 
	{
		/*read byte*/
		data = epd_data.image_data[sram_address+x] & 0xFF;
		/*inverse image if enabled*/
		if(epd_data.inverse_image) data=~data;
		/*write image data to buffer*/
		*(byte_array+x) = data;
	}
}

/**
 * \brief Read Flash data into buffer
 *
 * \param flash_address The start address of Flash
 * \param target_buffer The target address of buffer will be read
 * \param byte_length The data length will be read
 */
void sd_cmd_read(long line_address, uint8_t *target_buffer, uint8_t byte_length)
{
	uint8_t data[byte_length];
	uint8_t x;
	//read sd line
	_EPD_read_sd_handler(line_address, (uint8_t *)data, byte_length);
	/*read line data*/
	for (x =0 ; x < byte_length ; x++)
	{
		/*inverse image if enabled*/
		if(epd_data.inverse_image) data[x] = ~data[x];
		/*write image data to buffer*/
		*(target_buffer+x) = data[x];
	}
	
	//read_flash(flash_address,target_buffer,byte_length);
}

void display_white(uint8_t *byte_array, uint8_t byte_length)
{
	int x=0;
	for (x =0 ; x < byte_length ; x++)
	{
		/*inverse image if enabled*/
		if(epd_data.inverse_image) *(byte_array+x) = 0x00;
		else *(byte_array+x) = 0xFF;
		
	}
}