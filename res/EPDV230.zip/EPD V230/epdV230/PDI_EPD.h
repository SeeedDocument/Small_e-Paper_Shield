/**
* \file
*
* \brief The definition of Pervasive Displays Inc.'s EPDs
*
* Copyright (c) 2012-2014 Pervasive Displays Inc. All rights reserved.
*
*  Authors: Pervasive Displays Inc.
*
*  Modified by: Muchiri John
*  12/29/2014 12:49:39
* 
*  For: SeeedStudio EPD shield (c) 2014 Seeedstudio
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*  1. Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*  2. Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef PDI_EPD_H_INCLUDED
#define PDI_EPD_H_INCLUDED


#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <avr/io.h>

#include <avr/io.h>
#include <Arduino.h>
#include <avr/pgmspace.h>

//sd image read handler function
typedef void (*EPD_read_from_sd_handler)(long line_address, uint8_t *target_buffer, uint8_t byte_length);


/*#define COG_V230_G2*/



#if !defined(FALSE)
#define FALSE 0 /**< define FALSE=0 */
#endif


#if !defined(TRUE)
#define TRUE (1) /**< define TRUE=1 */
#endif

#if !defined(NULL)
#define NULL (void *)0  /**< define NULL */
#endif

#if !defined(_NOP)
#define _NOP() asm("nop")
#endif

#if !defined(bool)
#define bool uint8_t
//typedef uint8_t bool
#endif

extern void delay_ms(unsigned int ms);
//#define delay delay_ms

#define LINE_SIZE	64  /**< maximum data line size */

/**
* \brief Support 1.44", 2" and 2.7" three type EPD */
enum EPD_SIZE {
	EPD_144,
	EPD_200,
	EPD_270
};

struct user_epd_data{
	unsigned int *image_data;
	uint8_t user_epd_type;
	uint8_t inverse_image;
}epd_data;

#ifdef __cplusplus
extern "C" {
#endif
	#include "EPD_hardware_driver.h"
	#include "EPD_controller.h"
	#include "EPD_COG_process.h"
#ifdef __cplusplus
}
#endif

/*cpp class wrapper*/
#ifdef __cplusplus

class PDI_EPD
{
	public:
	/*initialize with epd size and inverse image flag*/
	void Init(uint8_t epd_size, uint8_t inverse)
	{
		EPD_begin(epd_size, inverse);
		EPD_init();
	}
	
	/*init hardware io*/
	void InitIO()
	{
		EPD_init();
	}
	
	/*flash image*/
	void FlashImage(PROGMEM const unsigned int *flashImage)
	{
		EPD_image_flash(flashImage);
	}
	
	/*sram image*/
	void SramImage(uint8_t *sramImage)
	{
		EPD_image_sram(sramImage);
	}
	
	/*Clear epd*/
	void Clear()
	{
		EPD_clear();
	}

};

PDI_EPD EPDV230;

#endif /*end cpp class wrapper*/

#endif	//EPAPER_H_INCLUDED



