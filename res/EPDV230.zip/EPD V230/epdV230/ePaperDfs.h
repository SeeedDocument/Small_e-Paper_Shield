/*
  ePaperDfs.h
  2013 Copyright (c) Seeed Technology Inc.  All right reserved.

  Modified by Loovee
  www.seeedstudio.com
  2013-7-2
  
  Modified by Muchiri John
  12/29/2014 12:49:39
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef __EPAPERDFS_H__
#define __EPAPERDFS_H__

// pin define

typedef enum {
	DIRNORMAL,
	DIRLEFT,
	DIRRIGHT,
    DIRDOWN
} EPD_DIR;

#endif

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/