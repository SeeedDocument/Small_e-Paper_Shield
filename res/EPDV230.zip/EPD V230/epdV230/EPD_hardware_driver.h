/**
* \file
*
* \brief The SPI, PWM, Temperature definitions of COG hardware driver
*
* Copyright (c) 2012-2014 Pervasive Displays Inc. All rights reserved.
*
* Copyright (c) 2014 SeeedStudio Technology. All rights reserved.
*
*  Authors: Muchiri John.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*  1. Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*  2. Redistributions in binary form must reproduce the above copyright
*     notice, this list of conditions and the following disclaimer in
*     the documentation and/or other materials provided with the
*     distribution.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
*  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

#ifndef 	DISPLAY_HARDWARE_DRIVCE_H_INCLUDED_
#define 	DISPLAY_HARDWARE_DRIVCE_H_INCLUDED_


#include <avr/io.h>

#include "PDI_EPD.h"

//gpio assignments
//pin assignments on seeed epaper shield
#define Pin_TEMPERATURE		A0
#define Pin_PANEL_ON		2
#define Pin_BORDER			3
#define Pin_DISCHARGE		8
#define Pin_PWM				5
#define Pin_RESET			6
#define Pin_BUSY			7

#define Pin_EPD_CS			10
#define Pin_Font_Cs			9

#define Pin_SD_CS			4

#define Pin_OE123			A1
#define Pin_STV_IN			A3

#define pin_spi_mosi		11
#define pin_spi_miso		12
#define pin_spi_sck			13

uint8_t EPD_IsBusy(void);
void EPD_cs_high (void);
void EPD_cs_low (void);
void EPD_SD_cs_high(void);
void EPD_SD_cs_low (void);
void EPD_rst_high (void);
void EPD_rst_low (void);
void EPD_discharge_high (void);
void EPD_discharge_low (void);

void EPD_Vcc_turn_off (void);
void EPD_Vcc_turn_on (void);

void EPD_border_high(void);
void EPD_border_low (void);

void SPIMISO_low(void);
void SPIMOSI_low(void);
void SPICLK_low(void);
void EPD_initialize_gpio(void);

//spi methods and assignments
void epd_spi_init (void);
void epd_spi_attach (void);
void epd_spi_detach (void);
void epd_spi_send (unsigned char Register, unsigned char *Data, unsigned Length);
void epd_spi_send_byte (uint8_t Register, uint8_t Data);
uint8_t epd_spi_read(unsigned char RDATA);
void epd_spi_write (unsigned char Data);
uint8_t epd_spi_write_ex (unsigned char Data);
void sys_delay_ms(unsigned int ms);
void start_EPD_timer(void);
void stop_EPD_timer(void);
void PWM_start_toggle(void);
void PWM_stop_toggle(void);
void PWM_run(uint16_t time);
int16_t get_temperature(void);
void EPD_display_hardware_init (void);

//COG_V230 register
uint8_t SPI_R(uint8_t Register, uint8_t Data);

#endif 	//DISPLAY_HARDWARE_DRIVCE_H_INCLUDED_
