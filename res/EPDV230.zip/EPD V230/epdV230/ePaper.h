/*
  ePaper.h
  2013 Copyright (c) Seeed Technology Inc.  All right reserved.

  Modified by Loovee
  www.seeedstudio.com
  2013-7-2
  
  Modified by Muchiri John
  12/29/2014 12:49:39
  
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

#ifndef __EPAPER_H__
#define __EPAPER_H__

#include <Arduino.h>
#include <SPI.h>
#include <SD.h>

#include "PDI_EPD.h"
#include "GT20L16_drive.h"
#include "sd_epaper.h"
#include "ePaperDfs.h"

#define EP_DEBUG            1

#if EP_DEBUG
#define print_ep(X)         Serial.print(X)
#define println_ep(X)       Serial.println(X)
#else
#define print_ep(X)
#define println_ep(X)
#endif


class ePaper
{

private:
    unsigned char tMatrix[32];
    
    int SIZE_LEN;
    int SIZE_WIDTH;
    
    int DISP_LEN;
    int DISP_WIDTH;
    
    EPD_DIR direction;
    
public:
    
    void begin();
	
	void init(uint8_t epd_size, uint8_t inverse)
	{
		EPD_begin(epd_size, inverse);
		EPD_init();
	}
    
    void setDirection(EPD_DIR dir);
	
    unsigned char display();                // refresh 
    
    void image_flash(PROGMEM const unsigned int *image)           // read image from flash
    {
        EPD_image_flash(image);
    } 
 
    void clear()                             // clear display
    {
        EPD_clear();
    } 
    
    void clear_sd();                         // clear sd card 

   
    void spi_detach();
#if defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
    void image_sram(uint8_t *image)
    {
        EPD_image_sram(image);
    }
#endif
    
    inline void drawPixel(int x, int y, unsigned char color)
    {
		eSD.putPixel(x, y, color);
        
	}
	
    /*void sd_read(long line_address, uint8_t *target_buffer, uint8_t byte_length)
	{
		SPI.begin();
		eSD.getLine(line_address, target_buffer, byte_length);
	}*/
	
	
    int drawChar(char c, int x, int y);
    int drawString(char *string, int poX, int poY);
    int drawNumber(long long_num,int poX, int poY);
    int drawFloat(float floatNumber,int decimal,int poX, int poY);
    
    int drawUnicode(unsigned int uniCode, int x, int y);
    int drawUnicode(unsigned char *matrix, int x, int y);
    
    int drawUnicodeString(unsigned int *uniCode, int len, int x, int y);
    
    void drawLine(int x0, int y0, int x1, int y1);
    void drawCircle(int poX, int poY, int r);
    void drawHorizontalLine( int poX, int poY, int len);
    void drawVerticalLine( int poX, int poY, int len);
    void drawRectangle(int poX, int poY, int len, int width);
    void fillRectangle(int poX, int poY, int len, int width);
    void fillCircle(int poX, int poY, int r);
    void drawTraingle( int poX1, int poY1, int poX2, int poY2, int poX3, int poY3);
};

static void sd_read(long line_address, uint8_t *target_buffer, uint8_t byte_length)
{
	uint8_t data[byte_length];
	uint8_t fbyte = 0;
	uint8_t tempbyte = 0;
	uint8_t dt = 0;
	uint8_t x, y;
	
	SPI.begin();
	eSD.getLine(line_address, (uint8_t *)data, byte_length);
	
	for(x = 0; x<byte_length; x++)
	{
		fbyte = 0;
		tempbyte = ~((data[x]) & 0xFF);
		dt = 0;
		for (y = 0; y < 8; y++)
		{
			if (((1 << y) == (tempbyte & (1 << y))))
			dt = 1;
			else
			dt = 0;

			fbyte |= dt << (7 - y);
		}
		
		*(target_buffer+x) = fbyte;//data[x];
	}
	//Serial.println(line_address);
}
/*
static void spi_on()
{
    SPI.begin();
}
*/

/*********************************************************************************************************
* \brief According to EPD size and temperature to get stage_time
* \note Refer to COG document Section 5.3 for more details
*
* \param EPD_type_index The defined EPD size
**********************************************************************************************************/
void ePaper::begin()
{
    direction = DIRNORMAL;
    
    switch(epd_data.user_epd_type)
    {
        case EPD_144:              // 128*96
        SIZE_LEN    = 128;
        SIZE_WIDTH  = 96;
        break;
        
        case EPD_200:               // 200*96
        SIZE_LEN    = 200;
        SIZE_WIDTH  = 96;
        break;
        
        case EPD_270:               // 264*176
        SIZE_LEN    = 264;
        SIZE_WIDTH  = 176;
        break;
        
        default:
        println_ep("wrong size");
        while(1);                   // die here
    }
    
    DISP_LEN    = SIZE_LEN;
    DISP_WIDTH  = SIZE_WIDTH;
    
    /*EPD.begin(size);
    init_io();*/
	EPD_init();
	SPI.begin();
}

void ePaper::spi_detach()
{
}
/*********************************************************************************************************
** Function name:           begin
** Descriptions:            begin
*********************************************************************************************************/
void ePaper::setDirection(EPD_DIR dir)
{
    direction = dir;
    
    if((direction == DIRLEFT) || (direction == DIRRIGHT))
    {
        DISP_LEN    = SIZE_WIDTH;
        DISP_WIDTH  = SIZE_LEN;
    }
    
    eSD.setDirection(direction);
}

/*********************************************************************************************************
** Function name:           drawUnicode
** Descriptions:            draw a unicode
*********************************************************************************************************/
int ePaper::drawUnicode(unsigned int uniCode, int x, int y)
{
    
   // if(((x+16)>= DISP_LEN) || ((y+16) >= DISP_WIDTH) || x<0 || y<0) return 0;
   

    int dtaLen = GT20L16.getMatrixUnicode(uniCode, tMatrix);


    int pX      = 0;
    int pY      = 0;
    int color   = 0;
    //spi_on();
    for(int k = 0; k<2; k++)
    {
        for(int i=0; i<8; i++)
        {
            for(int j=0; j<(dtaLen/2); j++)
            {

                if(tMatrix[j+(dtaLen/2)*k] & (0x01<<(7-i)))
                {  
                    color = 1;
                }
                else
                {
                    color = 0;
                }
                
                pX = x + j;
                pY = y + k*8+i;
                
                
                drawPixel(pX, pY, color);
            }
        }
    }

    return dtaLen/2;        // x +
}

int ePaper::drawUnicode(unsigned char *matrix, int x, int y)
{
    
   // if(((x+16)>= DISP_LEN) || ((y+16) >= DISP_WIDTH) || x<0 || y<0) return 0;
   

    int dtaLen  = 32;
    int pX      = 0;
    int pY      = 0;
    int color   = 0;
    //spi_on();
    for(int k = 0; k<2; k++)
    {
        for(int i=0; i<8; i++)
        {
            for(int j=0; j<(dtaLen/2); j++)
            {

                if(matrix[j+(dtaLen/2)*k] & (0x01<<(7-i)))
                {  
                    color = 1;
                }
                else
                {
                    color = 0;
                }
                
                pX = x + j;
                pY = y + k*8+i;
                
                drawPixel(pX, pY, color);
            }
        }
    }

    return dtaLen/2;        // x +
}

/*********************************************************************************************************
** Function name:           drawUnicodeString
** Descriptions:            draw string
*********************************************************************************************************/
int ePaper::drawUnicodeString(unsigned int *uniCode, int len, int x, int y)
{
    int xPlus = 0;
    int xSum  = 0;
    
    for(int i=0; i<len; i++)
    {
        xPlus = drawUnicode(uniCode[i], x, y);
        x += xPlus;
        xSum += xPlus;
    }
    return xSum;
}

/*********************************************************************************************************
** Function name:           drawChar
** Descriptions:            draw char
*********************************************************************************************************/
int ePaper::drawChar(char c, int x, int y)
{
    return drawUnicode(c, x, y);
}

/*********************************************************************************************************
** Function name:           drawString
** Descriptions:            draw string
*********************************************************************************************************/
int ePaper::drawString(char *string, int poX, int poY)
{
    int sumX = 0;

    while(*string)
    {
        
        int xPlus = drawChar(*string, poX, poY);
        sumX += xPlus;
        *string++;
        
        if(poX < 200)
        {
            poX += xPlus;                                     /* Move cursor right            */
        }
    }
    
    return sumX;
}

/*********************************************************************************************************
** Function name:           drawNumber
** Descriptions:            drawNumber
*********************************************************************************************************/
int ePaper::drawNumber(long long_num,int poX, int poY)
{
    char tmp[10];
    sprintf(tmp, "%d", long_num);
    return drawString(tmp, poX, poY);

}

/*********************************************************************************************************
** Function name:           drawFloat
** Descriptions:            drawFloat
*********************************************************************************************************/
int ePaper::drawFloat(float floatNumber, int decimal, int poX, int poY)
{
    unsigned long temp=0;
    float decy=0.0;
    float rounding = 0.5;
    unsigned char f=0;
    
    float eep = 0.000001;
    
    int sumX    = 0;
    int xPlus   = 0;
    
    if(floatNumber-0.0 < eep)       // floatNumber < 0
    {
        xPlus = drawChar('-',poX, poY);
        floatNumber = -floatNumber;

        poX  += xPlus; 
        sumX += xPlus;
    }
    
    for (unsigned char i=0; i<decimal; ++i)
    {
        rounding /= 10.0;
    }
    
    floatNumber += rounding;

    temp = (long)floatNumber;
    
    
    xPlus = drawNumber(temp,poX, poY);

    poX  += xPlus; 
    sumX += xPlus;

    if(decimal>0)
    {
        xPlus = drawChar('.',poX, poY);
        poX += xPlus;                                       /* Move cursor right            */
        sumX += xPlus;
    }
    else
    {
        return sumX;
    }
    
    decy = floatNumber - temp;
    for(unsigned char i=0; i<decimal; i++)                                      
    {
        decy *= 10;                                                      /* for the next decimal         */
        temp = decy;                                                    /* get the decimal              */
        xPlus = drawNumber(temp,poX, poY);
        
        poX += xPlus;                                       /* Move cursor right            */
        sumX += xPlus;
        decy -= temp;
    }
    return sumX;
}

/*********************************************************************************************************
** Function name:           drawLine
** Descriptions:            drawLine
*********************************************************************************************************/
void ePaper::drawLine(int x0, int y0, int x1, int y1)
{

    EPD_init();
    SPI.begin();
    
    int x = x1-x0;
    int y = y1-y0;
    int dx = abs(x), sx = x0<x1 ? 1 : -1;
    int dy = -abs(y), sy = y0<y1 ? 1 : -1;
    int err = dx+dy, e2;                                              
    for (;;)
    {                                                          
        drawPixel(x0,y0,1);
        e2 = 2*err;
        if (e2 >= dy) 
        {                                                
            if (x0 == x1) break;
            err += dy; x0 += sx;
        }
        if (e2 <= dx) 
        {                                                
            if (y0 == y1) break;
            err += dx; y0 += sy;
        }
    }
}


/*********************************************************************************************************
** Function name:           clear_sd
** Descriptions:            clear sd card
*********************************************************************************************************/
void ePaper::clear_sd()
{
    
    EPD_init();
    SPI.begin();
    
    for(int i=0; i<DISP_WIDTH; i++)
    {
        for(int j=0; j<DISP_LEN; j++)
        {
            drawPixel(j, i, 0);
            
        }
    }
}

/*********************************************************************************************************
** Function name:           drawCircle
** Descriptions:            drawCircle
*********************************************************************************************************/
void ePaper::drawCircle(int poX, int poY, int r)
{

    EPD_init();
    SPI.begin();
	
    int x = -r, y = 0, err = 2-2*r, e2;
    do {
        drawPixel(poX-x, poY+y, 1);
        drawPixel(poX+x, poY+y, 1);
        drawPixel(poX+x, poY-y, 1);
        drawPixel(poX-x, poY-y, 1);
        e2 = err;
        if (e2 <= y) {
            err += ++y*2+1;
            if (-x == y && e2 <= x) e2 = 0;
        }
        if (e2 > x) err += ++x*2+1;
    } while (x <= 0);
}

/*********************************************************************************************************
** Function name:           drawHorizontalLine
** Descriptions:            drawHorizontalLine
*********************************************************************************************************/
void ePaper::drawHorizontalLine( int poX, int poY, int len)
{
    drawLine(poX, poY, poX+len, poY);
}

/*********************************************************************************************************
** Function name:           drawVerticalLine
** Descriptions:            drawVerticalLine
*********************************************************************************************************/
void ePaper::drawVerticalLine( int poX, int poY, int len)
{
    drawLine(poX, poY, poX, poY+len);
}

/*********************************************************************************************************
** Function name:           drawRectangle
** Descriptions:            drawRectangle
*********************************************************************************************************/
void ePaper::drawRectangle(int poX, int poY, int len, int width)
{
    drawHorizontalLine(poX, poY, len);
    drawHorizontalLine(poX, poY+width, len);
    drawVerticalLine(poX, poY, width);
    drawVerticalLine(poX + len, poY, width);
}

/*********************************************************************************************************
** Function name:           fillCircle
** Descriptions:            fillCircle
*********************************************************************************************************/
void ePaper::fillCircle(int poX, int poY, int r)
{
    int x = -r, y = 0, err = 2-2*r, e2;
    
    do {

        drawVerticalLine(poX-x, poY-y, 2*y);
        drawVerticalLine(poX+x, poY-y, 2*y);

        e2 = err;
        if (e2 <= y) {
            err += ++y*2+1;
            if (-x == y && e2 <= x) e2 = 0;
        }
        if (e2 > x) err += ++x*2+1;
    } while (x <= 0);

}

/*********************************************************************************************************
** Function name:           drawTraingle
** Descriptions:            drawTraingle
*********************************************************************************************************/
void ePaper::drawTraingle( int poX1, int poY1, int poX2, int poY2, int poX3, int poY3)
{
    drawLine(poX1, poY1, poX2, poY2);
    drawLine(poX1, poY1, poX3, poY3);
    drawLine(poX2, poY2, poX3, poY3);
}

/*********************************************************************************************************
** Function name:           drawTraingle
** Descriptions:            drawTraingle
*********************************************************************************************************/
void ePaper::fillRectangle(int poX, int poY, int len, int width)
{
    for(int i=0; i<width; i++)
    {
        drawHorizontalLine(poX, poY+i, len);
    }
}

/*********************************************************************************************************
** Function name:           display
** Descriptions:            you should use this function once after finish drawing
*********************************************************************************************************/
unsigned char ePaper::display()
{
#if defined(__AVR_ATmega32U4__) || defined(__AVR_ATmega328P__)
    EPD_image_sd(sd_read);
#elif defined(__AVR_ATmega1280__) || defined(__AVR_ATmega2560__)
    EPD_image_sram(eSD.sram_image);
#endif
}

/*
void ePaper::sd_read(long line_address, uint8_t *target_buffer, uint8_t byte_length)
{
	/ *uint8_t x;
	for(x=0; x<byte_length; x++)
	{
		*(target_buffer+x) = / *(uint8_t)* /pgm_read_byte(&epdImage_270[line_address+x]) & 0xFF;
	}* /
	//Serial.println(line_address);
	/ *for (uint8_t line = 0; line < this->lines_per_display ; ++line)
	{* /
		SPI_on();
		eSD.getLine(line_address, target_buffer, byte_length);
	//}
}*/

ePaper EPAPER;

#endif

/*********************************************************************************************************
  END FILE
*********************************************************************************************************/
