/**
 * \file
 *
 * \brief The initialization and configuration of COG hardware driver
 *
 * Copyright (c) 2012-2014 Pervasive Displays Inc. All rights reserved.
 *
 * Copyright (c) 2014 SeeedStudio Technology. All rights reserved.
 *
 *  Authors: Muchiri John.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *  2. Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <math.h>
#include "EPD_hardware_driver.h"


static uint8_t spi_flag = FALSE;

//gpio

/**
* \brief Set EPD_CS pin to high
*/
void EPD_cs_high (void) {
	digitalWrite(Pin_EPD_CS, HIGH);
}

/**
* \brief Set EPD_CS pin to low
*/
void EPD_cs_low (void) {
	digitalWrite(Pin_EPD_CS, LOW);
}

/**
* \brief Set SD_CS pin to high
*/
void EPD_SD_cs_high(void) {
	digitalWrite(Pin_SD_CS, HIGH);
}

/**
* \brief Set SD_CS pin to low
*/
void EPD_SD_cs_low (void) {
	digitalWrite(Pin_SD_CS, LOW);
}

/**
* \brief Set /RESET pin to high
*/
void EPD_rst_high (void) {
	digitalWrite(Pin_RESET, HIGH);
}

/**
* \brief Set /RESET pin to low
*/
void EPD_rst_low (void) {
	digitalWrite(Pin_RESET, LOW);
}

/**
* \brief Set DISCHARGE pin to high
*/
void EPD_discharge_high (void) {
	digitalWrite(Pin_DISCHARGE, HIGH);
}

/**
* \brief Set DISCHARGE pin to low
*/
void EPD_discharge_low (void) {
	digitalWrite(Pin_DISCHARGE, LOW);
}


/**
* \brief Set Vcc (PANEL_ON) to high
**/
void EPD_Vcc_turn_on (void) {
	digitalWrite(Pin_PANEL_ON, HIGH);
}

/**
* \brief Set Vcc (PANEL_ON) to low
*/
void EPD_Vcc_turn_off (void) {
	digitalWrite(Pin_PANEL_ON, LOW);
}

/**
* \brief Set BORDER_CONTROL pin to high
*/
void EPD_border_high(void) {
	digitalWrite(Pin_BORDER, HIGH);
}

/**
* \brief Set BORDER_CONTROL pin to low
*/
void EPD_border_low (void) {
	digitalWrite(Pin_BORDER, LOW);
}

/**
* \brief Set PWM pin to high
*
void EPD_pwm_high(void) {
set_gpio_high(PWM_PORT,PWM_PIN);
}

*
* \brief Set PWM pin to low
*
void EPD_pwm_low (void) {
config_gpio_dir_o(SPIMISO_PORT,SPIMISO_PIN);
set_gpio_low(PWM_PORT,PWM_PIN);
}
*/
/**
* \brief Set MISO pin of SPI to low
*/
void SPIMISO_low(void) {
	pinMode(pin_spi_miso, OUTPUT);
	digitalWrite(pin_spi_miso, LOW);
}

/**
* \brief Set MOSI pin of SPI to low
*/
void SPIMOSI_low(void) {
	digitalWrite(pin_spi_mosi, LOW);
}

/**
* \brief Set Clock of SPI to low
*/
void SPICLK_low(void) {
	digitalWrite(pin_spi_sck, LOW);
}

/**
* \brief Get BUSY pin status
*/
uint8_t EPD_IsBusy(void) {
	return digitalRead(Pin_BUSY);
}

/**
* \brief Configure GPIO
*/
void EPD_initialize_gpio(void) {
	pinMode(Pin_PANEL_ON, OUTPUT);
	pinMode(Pin_BORDER, OUTPUT);
	pinMode(Pin_DISCHARGE, OUTPUT);
	pinMode(Pin_RESET, OUTPUT);
	pinMode(Pin_EPD_CS, OUTPUT);

	pinMode(Pin_BUSY, INPUT);
	pinMode(Pin_SD_CS, OUTPUT);
	
	//font pin and chip select defs
	pinMode(Pin_Font_Cs, OUTPUT);
	digitalWrite(Pin_Font_Cs, HIGH);
}

//spi and temparature
/**
 * \brief Delay mini-seconds
 * \param ms The number of mini-seconds
 */
void delay_ms(unsigned int ms) {
	delay(ms);
}

/**
 * \brief Delay mini-seconds
 * \param ms The number of mini-seconds
 */
void sys_delay_ms(unsigned int ms) {
	delay_ms(ms);
}

static void Wait_10us(void) {
	delayMicroseconds(10);
}

//******************************************************************
//* PWM  Configuration/Control //PWM output : PD3
//******************************************************************

/**
 * \brief The PWM signal starts toggling
 */
void PWM_start_toggle(void) {
	analogWrite(Pin_PWM, 128); //pwm on 50% duty
}

/**
 * \brief The PWM signal stops toggling.
 */
void PWM_stop_toggle(void) {
	analogWrite(Pin_PWM, 0); //PWM off
}

/**
 * \brief PWM toggling.
 *
 * \param ms The interval of PWM toggling (mini seconds)
 */
void PWM_run(uint16_t ms) {
	//unsigned long  current_time = millis();
	PWM_start_toggle();
	//while (millis() < (current_time + ms)); //wait Delay Time
	delay(ms);
	PWM_stop_toggle();
}

//******************************************************************
//* SPI  Configuration
//******************************************************************

/**
 * \brief Configure SPI
 */
void epd_spi_init()
{
	//DDR_SPI = (1<<DD_MOSI)|(1<<DD_SCK);
	DDRB |= _BV(PORTB3) | _BV(PORTB5);
	DDRB &= ~_BV(PORTB4);
	//enable spi
	SPCR |= _BV(MSTR) | _BV(SPE);
	//msb first
	SPCR &= ~(_BV(DORD));
	//mode 0
	SPCR = (SPCR & ~0x0C) | 0x00;
}

/**
 * \brief Initialize SPI
 */
void epd_spi_attach(void) {
	EPD_SD_cs_high();
	EPD_cs_high();
	epd_spi_init();
	spi_flag = TRUE;
}

/**
 * \brief Disable SPI and change to GPIO
 */
void epd_spi_detach(void) {
	/*end spi transmission*/
	SPCR &= ~_BV(SPE);
	/*drive spi pins low*/
	SPIMISO_low();
	SPIMOSI_low();
	SPICLK_low();
	spi_flag = FALSE;
}


/**
 * \brief SPI synchronous write
 */
void epd_spi_write(unsigned char Data) {
	/* Start transmission */
	SPDR = Data;
	/* Wait for transmission complete */
	while(!(SPSR & (1<<SPIF)))
	;
}
/**
 * \brief SPI synchronous read
 */
uint8_t epd_spi_read(unsigned char RDATA) {
        SPDR = RDATA;
	/* Wait for reception complete */
	while(!(SPSR & (1<<SPIF)))
	;
	/* Return Data Register */
	return SPDR;
}

/**
 * \brief Send data to SPI with time out feature
 *
 * \param data The data to be sent out
 */
uint8_t epd_spi_write_ex(unsigned char Data) {
	uint8_t cnt = 200;
	uint8_t flag = 1;
	SPDR = Data;
	while(!(SPSR & (1<<SPIF))) {
		if ((cnt--) == 0) {
			flag = 0;
			break;
		}
	}
	return flag;
}

//#if defined(COG_V230_G2)
/**
* \brief SPI command
*
* \param register_index The Register Index as SPI Data to COG
* \param register_data The Register Data for sending command data to COG
* \return the SPI read value
*/
uint8_t SPI_R(uint8_t Register, uint8_t Data) {
	uint8_t result;
	EPD_cs_high();
	Wait_10us();
	EPD_cs_low ();
	epd_spi_write(0x70); // header of Register Index
	epd_spi_write (Register);

	EPD_cs_high ();
	Wait_10us ();
	EPD_cs_low ();

	epd_spi_write(0x73); // header of Register Data of read command
	result=(uint8_t)epd_spi_read(Data);

	EPD_cs_high ();

	return result;
}
//#endif

/**
* \brief SPI command if register data is larger than two bytes
*
* \param register_index The Register Index as SPI command to COG
* \param register_data The Register Data for sending command data to COG
* \param length The number of bytes of Register Data which depends on which
* Register Index is selected.
*/
void epd_spi_send (unsigned char register_index, unsigned char *register_data,
               unsigned length) {
	EPD_cs_low ();
	epd_spi_write (0x70); // header of Register Index
	epd_spi_write (register_index);

	EPD_cs_high ();
	Wait_10us ();
	EPD_cs_low ();

	epd_spi_write (0x72); // header of Register Data of write command
	while(length--) {
		epd_spi_write (*register_data++);
	}
	EPD_cs_high ();
}

/**
* \brief SPI command
*
* \param register_index The Register Index as SPI command to COG
* \param register_data The Register Data for sending command data to COG
*/
void epd_spi_send_byte (uint8_t register_index, uint8_t register_data) {
	EPD_cs_low ();
	epd_spi_write (0x70); // header of Register Index
	epd_spi_write (register_index);

	EPD_cs_high ();
	Wait_10us ();
	EPD_cs_low ();
	epd_spi_write (0x72); // header of Register Data
	epd_spi_write (register_data);
	EPD_cs_high ();
}

//******************************************************************
//* Temperature sensor  Configuration
//******************************************************************

int16_t get_temperature(void) {
	long temp;
	int i;
	int sum = 0;
	
	for(i=0; i<32; i++)
	{
		sum += analogRead(Pin_TEMPERATURE);
	}
	sum  = sum >> 5;

	temp = 209.56-121.7*((float)sum/1023.0*5.0);

	return (int)temp;
}

/**
 * \brief Initialize the seeed EPD shield hardware setting
 */
void EPD_display_hardware_init(void) {
	EPD_initialize_gpio();
	epd_spi_init();
	EPD_Vcc_turn_off();
	EPD_cs_high();
	EPD_SD_cs_high();
	EPD_rst_high();
	EPD_discharge_low();
	EPD_border_low();
}

